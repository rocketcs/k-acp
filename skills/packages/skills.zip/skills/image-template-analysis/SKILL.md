---
name: image-template-analysis
description: 对用户上传的参考图进行大屏视觉识别，并在识图前约束模型输出唯一、可编辑的大屏模板。用于大屏生图智能体收到 `[large-screen-image action=analyze]` 且附有 PNG、JPG、JPEG 或 WEBP 参考图时；输出布局、层级、组件、配色、关系和可替换内容的结构化 JSON。
---

# 大屏参考图模板识别

仅在用户消息包含 `[large-screen-image action=analyze ...]` 且具有可读取图片附件时执行。把该附件作为唯一参考图；不要要求用户重复描述图片。

## 工作方式

1. 读取图片，只记录真实可见的布局、视觉、文字层级、图表形态、连接关系和色彩。
2. 将结果规范为下方唯一的 `large-screen-image-plan` JSON 模板。
3. 此模板是后续生成动作的视觉约束来源。后续 `[large-screen-image action=generate ...]` 必须保留其锁定区域、锁定关系、画布比例和整体配色比例，除非用户明确要求重新布局。

不要编造品牌、数字、地理位置、人员身份、实时状态、交互能力或图片不可见内容。看不清时用泛化描述，并将 `confidence` 降为 `LOW` 或 `MEDIUM`。

## 最终输出契约

最终回复必须且只能是一个完整代码块：不输出问候、解释、Markdown 标题、工具日志或第二个代码块。

```large-screen-image-plan
{
  "version": "2",
  "title": "不超过 48 字的模板标题",
  "confidence": "HIGH",
  "observedVisualFacts": ["仅限图片中可观察到的事实"],
  "canvas": {"ratio": "16:9", "coordinateSystem": "normalized-1000", "grid": "12-column"},
  "visualTokens": {"palette": ["#0B1F3A", "#1C5D99"], "surface": "深色渐变背景", "border": "低对比细描边", "typography": "无衬线中文字体"},
  "regions": [{"id": "header", "label": "标题状态区", "bounds": {"x": 0, "y": 0, "width": 1000, "height": 120}, "layer": 1, "component": "title-status", "purpose": "展示标题与全局状态", "locked": true, "replaceable": ["title", "statusText"]}],
  "relations": [],
  "preservation": {"mode": "preserve-layout", "mustKeep": ["region-bounds", "information-hierarchy", "locked-relations", "palette-proportion"], "mayReplace": ["business-labels", "metric-meanings", "chart-data", "icons"]},
  "prompt": "基于模板的完整正向生成提示词",
  "negativePrompt": "应避免的视觉问题",
  "iterationHints": ["可选的后续调整建议"]
}
```

## 字段规则

- `version` 固定为 `"2"`；`confidence` 仅为 `HIGH`、`MEDIUM` 或 `LOW`。
- `canvas.ratio` 根据图片实际比例选择 `16:9`、`21:9` 或 `9:16`；坐标始终是 0–1000 的整数画布。
- `regions` 列出 1–18 个真实视觉区域。`bounds` 不得越界；`layer` 为正整数；区域 ID 唯一。
- `component` 仅使用：`title-status`、`metric-grid`、`line-chart`、`bar-chart`、`area-chart`、`pie-chart`、`gauge`、`map`、`topology-cluster`、`core-topology`、`alert-feed`、`list`、`timeline`、`data-table`、`image-panel`、`footer-status`。
- `relations` 只描述图片中明确可见的连接或从属关系；`kind` 使用 `topology-link`、`flow-link`、`dependency-link`、`hierarchy-link` 或 `data-link`。
- `locked: true` 只用于需要保持的几何、主次层级或关键关系；业务文案、图表数据、图标等放进 `replaceable`。
- `palette` 只用 `#RRGGBB`；`observedVisualFacts` 只写可见事实，不写推断。

## 输出前自检

确认 JSON 可解析；根节点和嵌套对象字段完整；没有代码块外文字；每个关系引用已有区域；每个区域位于画布内；没有把猜测当事实。若图片不可读，仍输出同一结构，使用 `LOW` 置信度和保守、泛化的模板，绝不改成自然语言回复。
