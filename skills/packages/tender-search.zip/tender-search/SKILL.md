---
name: tender-search
description: 使用 K-ACP 中受限的认证 profile 查询和分析全网招标、中标、采购、供应商、竞争对手、项目详情、价格趋势与市场数据。凡是标讯搜索、企业招投标分析、采购寻源、商机分析或原始公告链接解析，都使用本 Skill。
---

# 标讯搜索与分析

## 运行时契约

只能使用已绑定的 K-ACP 工具，不读取环境变量、用户目录或密钥文件。

| 工具 | 用途 | 必填参数 |
|---|---|---|
| `http_request` | 调用标讯 API | `url`、`method`、`headers_json`、`body`、`auth_profile`、`timeout_seconds` |
| `wenbiao_agent_key_pool` | 查询或轮换**已授权**的密钥 | `action`；轮换时还需 `provider_status` |
| `resolve_tender_source_urls` | 从聚合页提取展示项目的原始公告链接 | `items` |
| `get_current_datetime` | 解释“最近一个月”等相对时间 | 无 |

认证固定使用 `auth_profile: "wenbiao_agent"`。profile 在服务器端注入 `X-API-Key` 和 `X-Client`，不得在提示词、工具参数、日志或回答中出现完整密钥。

禁止调用任何注册、登录、设备指纹或自动获取密钥的接口；也不要读取或要求 `ZLBX_API_KEY`、`~/.zlbx/config.json`、`auto-register.md`。

## `http_request` 参数

每个字段都必须按下表传入；`headers_json` 与 `body` 都是 JSON **字符串**，不是对象。

| 参数 | 类型 | 必填 | 值 |
|---|---:|---:|---|
| `url` | string | 是 | `https://mcp-server.zhiliaobiaoxun.com/api_v2/<endpoint>` |
| `method` | string | 是 | 标讯 API 一律 `POST` |
| `headers_json` | string | 是 | `{"Content-Type":"application/json"}` |
| `body` | string | 是 | 请求体序列化后的 JSON 字符串 |
| `auth_profile` | string | 是 | `wenbiao_agent` |
| `timeout_seconds` | integer | 是 | `30`，允许范围 1–60 |

标准调用模板：

```json
{
  "url": "https://mcp-server.zhiliaobiaoxun.com/api_v2/search_bids",
  "method": "POST",
  "headers_json": "{\"Content-Type\":\"application/json\"}",
  "body": "{\"keywords\":[\"统一系统维护\"],\"provinces\":[\"广东\"],\"begin_date\":\"2026-06-23\",\"end_date\":\"2026-07-23\",\"page\":1,\"page_size\":20}",
  "auth_profile": "wenbiao_agent",
  "timeout_seconds": 30
}
```

工具返回对象的稳定字段为：`success`、`status`、`method`、`url`、`content_type`、`truncated`；JSON 响应在 `data`，非 JSON 文本在 `body`。先判断 HTTP 工具的 `success`，再判断供应商响应的 `data.success`。

## 搜索流程

1. 遇到相对时间先调用 `get_current_datetime`，将范围转成 `YYYY-MM-DD`。
2. 根据请求选择 endpoint 与请求体。读取所需的参考文件：
   - `references/api-search.md`：`search_bids`、`query_bids_advanced`、详情、临期项目。
   - `references/api-company.md`：企业与竞争对手分析。
   - `references/api-market.md`：采购方、供应商、品牌和价格趋势。
3. 用上面的完整 `http_request` 契约发送请求。`page_size` 最大 50。
4. 只根据 `data` 中实际返回的项目字段回答，不编造预算、联系人、状态或原始链接。
5. 需要原始链接时，调用 `resolve_tender_source_urls`，传入展示批次（1–20 条）的 `items`。每项使用已返回的 `bid_id`、`title`，并尽量携带 `source_url`、`aggregate_url` 或 `url`：

```json
{
  "items": [
    {
      "bid_id": "123456",
      "title": "示例项目",
      "source_url": "",
      "aggregate_url": "https://www.zhiliaobiaoxun.com/content/123456/b1"
    }
  ]
}
```

只把 resolver 返回 `status: "EXTRACTED"` 的 `original_url` 标为“原始公告链接”。该状态表示链接已从知了页面提取并完成公网地址安全校验，未对原始公告站点做可达性探测。

## 余额不足时的轮换流程

从 `http_request.data.error.code` 读取供应商错误码。只有下列两个精确值可以轮换：

- `INSUFFICIENT_BALANCE`
- `QUOTA_EXCEEDED`

调用格式：

```json
{
  "action": "rotate",
  "provider_status": "INSUFFICIENT_BALANCE",
  "exclude_fingerprints": []
}
```

`wenbiao_agent_key_pool` 参数含义：

| 参数 | 类型 | 必填 | 可用值 |
|---|---:|---:|---|
| `action` | string | 是 | `status`、`rotate`、`mark_failure` |
| `provider_status` | string | 仅 `rotate` / `mark_failure` | `INSUFFICIENT_BALANCE`、`QUOTA_EXCEEDED` |
| `exclude_fingerprints` | string[] | 否 | 本请求已尝试过的工具返回 fingerprint；默认 `[]` |

轮换规则：

1. 记录本次失败的 fingerprint（若工具响应中存在），调用 `rotate`。
2. 仅当工具返回 `success: true` 时，原样重试**同一个** `http_request` 一次。
3. 一个用户请求最多执行 3 个“轮换 + 重试”周期；仍失败或工具返回 `NO_USABLE_STANDBY_KEY` 时停止。
4. `AUTHENTICATION_FAILED`、`RATE_LIMITED`、`INVALID_REQUEST` 或 HTTP 工具错误不轮换。分别提示检查服务器 profile、稍后重试、修正请求参数或检查网络。

`status` 仅用于诊断，返回池大小、状态计数和 fingerprint，不返回密钥。`mark_failure` 只用于经确认的额度/配额故障，正常搜索流程应直接使用 `rotate`。

## 常用检索语义

- 查采购方发布项目：`match_modes: ["caller"]`。
- 查供应商中标：`match_modes: ["winner"]`，并使用 `bid_process: [7,8]`。
- 多条件 AND 或排除词：使用 `query_bids_advanced` 的 `keyword_groups`、`exclude_keywords`。
- `bid_process` 默认范围为 `[1,2,4,7,8]`；用户只要招标公告时使用 `[4]`，只要中标结果时使用 `[7,8]`。

## 输出要求

列出项目时优先呈现标题、公告阶段、发布时间、地区、采购方、金额（若返回）和已提取的原始链接。没有原始链接时明确写“未提取到原始公告链接”，不要用聚合页 URL 冒充原始链接。
