package com.kingsware.kient.node.base.feature;

/**
 * 描述：可操作消息队列节点的接口
 *
 **/
public interface OperableMqNode {
}
