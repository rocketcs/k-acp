package com.kingsware.kient.node.base;

/**
 * 描述：节点配置
 *
 **/
public interface NodeConfig {
}
