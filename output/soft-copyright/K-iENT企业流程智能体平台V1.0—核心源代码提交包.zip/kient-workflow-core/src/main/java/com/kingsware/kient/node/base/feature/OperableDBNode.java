package com.kingsware.kient.node.base.feature;

/**
 * 描述：可操作数据库节点的接口
 *
 **/
public interface OperableDBNode {
}
