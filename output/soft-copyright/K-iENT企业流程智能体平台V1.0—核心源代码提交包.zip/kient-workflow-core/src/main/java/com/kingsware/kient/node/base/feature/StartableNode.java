package com.kingsware.kient.node.base.feature;

/**
 * 描述：可以作为开始节点的接口
 *
 **/
public interface StartableNode {
}
