package com.kingsware.kient.node.base.template;

/**
 * 描述：枚举
 *
 **/
public enum FormatterType {
    STRING, JACKSON, VELOCITY
}
