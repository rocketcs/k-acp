package com.kingsware.kient.node.agent;

import com.fasterxml.jackson.databind.JsonNode;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 智能体节点执行请求。
 *
 */
@Getter
@Setter
public class AgentNodeRequest {
    private String workflowInstanceId;
    private String nodeId;
    private String nodeName;
    private Long modelConfigId;
    private boolean modelParamsOverrideEnabled;
    private JsonNode modelParamsOverride;
    private String systemPrompt;
    private String userPrompt;
    private List<Long> skillPackageIds = new ArrayList<>();
    private List<Long> toolIds = new ArrayList<>();
    private List<McpConfig> mcps = new ArrayList<>();
    private int maxIterations;
    private boolean structuredOutputEnabled;
    private JsonNode structuredOutput;
    private Map<String, Object> inputs;
}
