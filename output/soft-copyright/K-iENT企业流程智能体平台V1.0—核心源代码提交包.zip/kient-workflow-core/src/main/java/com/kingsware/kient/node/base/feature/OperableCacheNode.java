package com.kingsware.kient.node.base.feature;

/**
 * 描述：可操作缓存节点接口
 *
 **/
public interface OperableCacheNode {
}
