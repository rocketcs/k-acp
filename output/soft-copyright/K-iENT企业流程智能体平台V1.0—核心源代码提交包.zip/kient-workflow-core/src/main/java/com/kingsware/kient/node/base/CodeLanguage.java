package com.kingsware.kient.node.base;

/**
 * 描述：代码语言
 *
 **/
public enum CodeLanguage {
    JAVA,
    JAVASCRIPT
}
